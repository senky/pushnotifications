1. Copy vr.php file to root folder of your phpBB installation (where config.php is).
2. In your browser navigate to <YOUR_BOARD_URL>/vr.php